# -*- coding: utf-8 -*-

from . import ir_attachment
from . import ir_model
from . import report_excel
from . import xlsx
