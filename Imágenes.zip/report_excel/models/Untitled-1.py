class FalconSoft(self):
        self.username = 'falconsoft3d'
        self.name = 'Marlon Falcón Hernández'
        self.web = 'https://marlonfalcon.com'
        self.twitter = '@MarlonFalcon4'
        self.linkedin = 'https://www.linkedin.com/in/marlon-falc%C3%B3n-3a2aa9a4/'
        self.source = {
            'born': ['Cuba','Habana','Ciego de Avila'],
            'I have lived': ['Chile','Santiago de Chile'],
            'Where I live': ['Spain','Valencia'],
        },
        self.studies = {
            'graduate': ['civil engineer','Camaguey'],
            'postgraduate': ['master in architecture','Havana']
        },
        self.architecture = ['MVC', 'microservices'],
        self.code = {
            'erp': ['odoo erp', 'sap r3'],
            'frontend': ['HTML', 'CSS', 'JavaScript', 'Boostrap','React','Redux'],
            'backend': ['Python', 'PHP', 'Flask', 'Django','Node.Js'],
            'database': ['PostgreSQL', 'MySQL', 'SQLite3', 'MongoDB'],
            'devops': ['Docker', 'Nginx', 'AWS', 'Heroku','Docker-compose'],
            'tools': ['GIT', 'GitHub', 'Bitbucket'],
            'ides': ['Visual Studio Code', 'PyCharm'],
            'misc': ['Firebase', 'SCRUM', 'GNU/Linux', 'IOS']
        },
        self.projects = {
            'partcombinator': [ https://github.com/partcombinator ][MERN],
            'pyerp': [ https://github.com/falconsoft3d/pyerp ][DJANGO],
            'reactlang': [ https://github.com/falconsoft3d/reactlang ][PWA],
            'knox-token-library-api': [ https://github.com/falconsoft3d/knox-token-library-api ][API, DOCKER, NODE, EXPRESS]
        }
        

    def __str__(self):
        return self.name


if __name__ == '__main__':
    me = FalconSoft()


