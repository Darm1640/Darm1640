
from odoo import fields, models


class HrEmployeeUnity(models.Model):
    """HrEmployeeUnity."""

    _name = 'hr.employee.obtain.value'
    _description = 'valores'

    salario = fields.Float(string="Salario Minimo" default="906000")
    uvt = fields.Float(string="UVT" default="36000")
    aux = fields.Float(string="Auxilio Transporte" default="106000")
